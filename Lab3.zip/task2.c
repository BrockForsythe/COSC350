#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
int main()
{
	int fd1, fd2;
	fd1 = open("foo.txt",O_RDWR | O_CREAT);
	fd2 = open("clone1.txt", O_RDWR | O_CREAT);

	char b[1];
	int nread;
	while ((nread = read(fd1, b, 1) > 0))
	{
		write(fd2,b,nread);	
	}
	return 0;
}
