#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/stat.h>

#define BUFF 1 //Read one byte at a time

int main(int argc, char** argv)
{
	char buf[BUFF];
	char fd1[] = "foo";
	char fd2[] = "foo1";
	char fd3[] = "foo12";

	int nread;
	int in1 = open(fd1, O_RDONLY);
	if(in1 == -1)
	{
		puts("Error opening read file");
		return 1;
	}

	int in2 = open(fd2, O_RDONLY, 0760);
	if(in2 == -1)
	{
		puts("Error opening read file");
		return 1;
	}
	//open write file
	umask(0);
	int out = open(fd3, O_WRONLY|O_CREAT, 0760);
	//Checks for error opening output file
	if(out == -1)
	{
		puts("Error opening output file");
		close(in1);
		close(in2);
		close(out);
		return 2;
	}
	while((nread = read(in1, buf, BUFF) > 0))
	{ //writes first file into output, checks error
		if(write(out, buf, nread) == -1)
		{
			printf("Writing error in file 1");
			return 3;
		}
	}
	close(in1);
	//Go to end of output file for second write
	lseek(out, 0, SEEK_END);
	while((nread = read(in2,buf,BUFF) > 0))
	{
		if(write(out,buf,nread) == -1)
		{
			printf("Writing error in file 2");
			return 3;
		}	
	}
	close(in2);
	close(out);
	if(nread == -1)
	{
		printf("read error");
		return 4;
	}
	return 0;
}
