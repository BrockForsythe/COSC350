#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/stat.h>

#define BUFF 32

void err_sys(char *str)
{
	printf("%s",str);
	exit(1);
}


int main()
{
	int fd1,fd2;
	//open both files to read from and write to
	fd1 = open("foo.txt", O_RDWR);
	fd2 = open("clone2.txt", O_RDWR | O_CREAT, 0777);
	char buf[BUFF];
	int nread;
	nread = read(fd1, buf, BUFF);
	//read up to 32 bytes and write to clone2 file
	if(write(fd2,buf,nread) != nread)
		err_sys("Write error");
	if(nread < 0){
		err_sys("Read error");
	}
	printf("Task complete");
	return 0;
}
